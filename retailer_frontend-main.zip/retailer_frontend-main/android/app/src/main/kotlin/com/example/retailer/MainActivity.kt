package com.example.retailer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

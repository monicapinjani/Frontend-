package com.example.wholesaler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

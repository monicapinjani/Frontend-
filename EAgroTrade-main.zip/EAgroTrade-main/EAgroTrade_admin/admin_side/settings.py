INSTALLED_APPS=[
    'django.contrib.admin',
    'django.contrib.auth',
    'rest_framework',
    'admin_side',
]